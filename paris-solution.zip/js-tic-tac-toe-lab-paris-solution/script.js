let currentPlayer;
let board;
const winningCombos = [
  [[0,0], [0,1], [0,2]],
  [[1,0], [1,1], [1,2]],
  [[2,0], [2,1], [2,2]],
  [[0,0], [1,0], [2,0]],
  [[0,1], [1,1], [2,1]],
  [[0,2], [1,2], [2,2]],
  [[0,0], [1,1], [2,2]],
  [[0,2], [1,1], [2,0]]
];
const squares = document.querySelectorAll('.square');

squares.forEach((square) => {
  square.addEventListener('click', handleClick);
});

function resetGame() {
  currentPlayer = 'x';
  board = [
    [null, null, null],
    [null, null, null],
    [null, null, null]
  ]
  squares.forEach((square) => {
    square.classList.remove('x', 'o');
  });
  refreshPrompt();
}

resetGame();

function handleClick(evt) {
  const element = evt.target;

  if(placeMark(element)) {
    checkForWinner();
  }
}

function placeMark(element) {
  // Coordinates are in [y,x] format with the origin at the top left.
  // Setting it up this way will have out graphical board mirror our
  // javascript board!

  const coordinates = getCoordinates(element);

  if (board[coordinates.y][coordinates.x]) {
    // square already taken
    return false;
  } else {
    // square is free, proceed
    board[coordinates.y][coordinates.x] = currentPlayer;

    // Place the mark on the DOM
    element.classList.add(currentPlayer);
    return true;
  }
}

function getCoordinates(element) {
  // this is known as destructuring assignment
  // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Destructuring_assignment
  let y, x;
  [y, x] = element
    .getAttribute('data-location')
    .split(',')
    .map((num) => Number(num));

  return {y: y, x: x};
}

function changePlayer() {
  currentPlayer = currentPlayer === 'x' ? 'o' : 'x';
  refreshPrompt();
}

function refreshPrompt() {
  const message = `It's ${currentPlayer}'s turn!`;
  document.querySelector('#prompt').innerText = message;
}

function checkForWinner() {
  const isWinner = winningCombos.some((combo) => {
    return combo.every((point) => {
      return board[point[0]][point[1]] === currentPlayer;
    });
  });

  if (isWinner) {
    // wait for the DOM to update so the mark is displayed before the alert
    setTimeout(() => {
      alert(`${currentPlayer} wins!`);
      resetGame();
    }, 50);
  } else {
    changePlayer();
  }
}

